# ========================================== IMPORT ==========================================
try:
    from pyrogram import Client, filters, idle, ContinuePropagation
    from pyrogram.types import Message, InlineKeyboardButton as button, InlineKeyboardMarkup
except ImportError:
    from os import system
    system("python3 -m pip install pyrogram tgcrypto")
    exit("( RUN THE‌ SCRIPT‌ AGAIN )")
from dictdb import db, listdb; steps, files, tedad, links = db("steps"), db("files"), db('tedad'), listdb('links')
from get_config import get_config, get; config = get(get_config())
steps, chats = db("steps"), db("chats")
channels = config.channels.replace(" ", "").split(","); print (channels)
from random import choice
from string import ascii_lowercase, ascii_uppercase; asc = ascii_lowercase+ascii_uppercase+"0987654321"
def creat_link():
    char = ''
    while True:
        for _ in range(10):
            char += choice(asc)
        if files.checkExist(char) == False:
            return char
        else:
            char = ''
# ========================================== START CLIENT ==========================================
name, api_id, api_hash, bot_token = str("o0k"), int(config.api_id), str(config.api_hash), str(config.bot_token)
app = Client(session_name=name, api_hash=api_hash, api_id=api_id, bot_token=bot_token)
with app:
    botU = app.get_me().username
# ========================================== Inline Button ==========================================
in_home = InlineKeyboardMarkup([
        [button("𝙐𝙥𝙡𝙤𝙖𝙙 📤", callback_data="Upload"), button(f"𝙈𝙮 𝙁𝙞𝙡𝙚𝙨 👀", callback_data="Myfiles")],
        [button("𝘾𝙡𝙤𝙨𝙚 ❌", callback_data="Close")]
        ])
in_get_file = InlineKeyboardMarkup([
        [button("𝘽𝙖𝙘𝙠 🔙", callback_data="Back")],
        [button("𝘾𝙡𝙤𝙨𝙚 ❌", callback_data="Close")]
        ])
def linkss():
    txt = ''
    mylist = []
    for channel in channels:
        if len(channel) >= 5 and channel != "":
            if channel not in mylist:
                txt += f"👉🏻 @{channel}\n"
        mylist.append(channel)
    return txt
channelss = linkss()

def check_join(app, user_id):
    if channels[0] != '':
        try:
            for channel in channels:
                app.get_chat_member(channel, user_id)
            return True
        except:
            return False
    return True
# ========================================== MAIN CODES ==========================================
@app.on_message(filters.private)
def main_e(app, m: Message):
    if check_join(app, m.from_user.id):
        raise ContinuePropagation
    else:
        m.reply(f"𝙃𝙀 𝙅𝙤𝙞𝙣𝙨 𝙊𝙪𝙧 𝘾𝙝𝙖𝙣𝙣𝙚𝙡 𝘼𝙣𝙙 𝙏𝙝𝙚𝙣 𝙋𝙧𝙚𝙨𝙨 𝙏𝙝𝙚 [ 𝘾𝙤𝙣𝙛𝙞𝙧𝙢 ✅ ] 𝘽𝙪𝙩𝙩𝙤𝙣.\n\n{channelss}", reply_markup=InlineKeyboardMarkup([
            [button("𝘾𝙤𝙣𝙛𝙞𝙧𝙢 ✅", callback_data="Check")]
            ]))
@app.on_message(filters.private&filters.regex(r"/get_.*"), group=0)
def on_get(app, m:Message):
    text ,chat_id = m.text, m.chat.id
    try:
        link = text.split("/get_")[1]
        infom = files.get_data(link).split("-")
        htpl = f'https://t.me/{botU}?start={link}'
        tedad.set_data_save(link, tedad.get_data(link)+1)
        app.copy_message(chat_id, infom[0], int(infom[1]), f"𝘿𝙤𝙬𝙣𝙡𝙤𝙖𝙙𝙨 » `{tedad.get_data(link)}`)\n__**Lɪɴᴋ**__ » `{htpl}`", reply_markup=InlineKeyboardMarkup([
            [button("( 𝙇𝙞𝙣𝙠 🔗 )", url=htpl)]
            ]))
    except (IndexError, AttributeError):
        m.reply("( __**Nᴏᴛ Fᴏᴜɴᴅ**__ )")
@app.on_message(filters.private&filters.command("start"), group=0)
def on_message(app, m:Message):
    user_id, command, chat_id = m.from_user.id, m.command, m.chat.id
    steps.set_data(user_id, "Home")
    try:
        link = command[1]
        infom = files.get_data(link).split("-")
        tedad.set_data_save(link, tedad.get_data(link)+1)
        app.copy_message(chat_id, infom[0], int(infom[1]), f"𝘿𝙤𝙬𝙣𝙡𝙤𝙖𝙙𝙨 » `{tedad.get_data(link)}` )")
    except (IndexError, AttributeError):
        m.reply("( __**Mᴀɪɴ Mᴇɴᴜ**__ )", reply_markup=in_home)
@app.on_message(filters.private&(filters.voice | filters.audio | filters.animation | filters.photo | filters.media | filters.sticker | filters.document), group=0)
def get_file(app, m:Message):
    user_id, chat_id, message_id = m.from_user.id, m.chat.id, m.message_id
    if steps.data_is(user_id, "get_file"):
        steps.set_data(user_id, "Home")
        links.add_list(user_id)
        link = creat_link()
        links.add_element(user_id, link)
        tedad.set_data_save(link, 0)
        htpl = f'https://t.me/{botU}?start={link}'
        files.set_data_save(link, f"{chat_id}-{message_id}")
        m.reply(f"𝘿𝙤𝙬𝙣𝙡𝙤𝙖𝙙 𝙇𝙞𝙣𝙠 »\n( `{htpl}` )", reply_markup=InlineKeyboardMarkup([
            [button("( 𝙇𝙞𝙣𝙠 🔗 )", url=htpl)]
            ]))
@app.on_callback_query()
def in_call(app, call):
    data, user_id, message_id, chat_id = call.data ,call.from_user.id, call.message.message_id, call.message.chat.id
    if data == "Upload":
        steps.set_data(user_id, "get_file")
        app.edit_message_text(chat_id, message_id, "𝙎𝙚𝙣𝙙 𝙔𝙤𝙪𝙧 𝙈𝙚𝙙𝙞𝙖 𝙏𝙤 𝙐𝙥𝙡𝙤𝙖𝙙 ♥️ :", reply_markup=in_get_file)
    elif data == "Back":
        steps.set_data(user_id, "Home")
        app.edit_message_text(chat_id, message_id, "𝙔𝙤𝙪 𝘼𝙧𝙚 𝘽𝙖𝙘𝙠 𝙏𝙤 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 🥂", reply_markup=in_home)
    elif data == "Myfiles":
        a, b = 1, ""
        me = [] if type(links.get_elemenet(user_id)) == bool else links.get_elemenet(user_id)
        for i in me:
            b += f"__**{str(a):3}**__: /get_{i}\n"; a += 1
        app.edit_message_text(chat_id, message_id, f"💎 𝙐𝙥𝙡𝙤𝙖𝙙𝙚𝙙 𝙁𝙞𝙡𝙚 »\n{b}", reply_markup=in_get_file)
    elif data == "Close":
        steps.set_data(user_id, "Home")
        app.delete_messages(chat_id, message_id)
    elif data == "Check":
        if check_join(app, user_id):
            steps.set_data(user_id, "Home")
            app.edit_message_text(chat_id, message_id, "𝙔𝙤𝙪 𝘼𝙧𝙚 𝘽𝙖𝙘𝙠 𝙏𝙤 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 🥂", reply_markup=in_home)
        else:
            call.answer("❌")
# ========================================== START CLIENT ==========================================
app.start(), print(f"@{botU} Started..."), idle(), app.stop()